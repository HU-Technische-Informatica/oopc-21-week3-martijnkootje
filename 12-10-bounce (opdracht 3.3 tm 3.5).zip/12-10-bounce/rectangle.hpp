//#ifndef RECTANGLE_HPP
//#define RECTANGLE_HPP
//#include "hwlib.hpp"
//
//
//class rectangle{
//protected:
//   hwlib::window & w;
//	int start_x;
//	int start_y;
//	int end_x;
//	int end_y;
//public:
//		rectangle(hwlib::window & w, int start_x, int start_y, int end_x, int end_y) : w(w){
////			start_x = start_X;
////			start_y = start_Y;
////			end_x = end_X;
////			end_y = end_Y;
//		}
//		int get_start_x(){ return start_x; }
//		int get_start_y(){ return start_y; }
//		int get_end_x(){ return end_x; }
//		int get_end_y(){ return end_y; }
//
//		void print();
//};
//
//#endif // RECTANGLE_HPP
